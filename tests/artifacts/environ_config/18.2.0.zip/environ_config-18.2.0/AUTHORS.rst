Credits
=======

``environ_config`` is written and maintained by `Hynek Schlawack <https://hynek.me/>`_.

The development is kindly supported by `Variomedia AG <https://www.variomedia.de/>`_.

A full list of contributors can be found in `GitHub's overview <https://github.com/hynek/environ_config/graphs/contributors>`_.

``environ_config`` wouldn't be possible without the `attrs project <http://www.attrs.org>`_.
